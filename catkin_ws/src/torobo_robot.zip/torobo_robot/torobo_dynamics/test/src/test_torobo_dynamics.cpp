#include <ros/ros.h>
#include <gtest/gtest.h>
#include <iostream>
#include <vector>
#include <cmath>
// #include "torobo_dynamics/torobo_dynamics.h"

using namespace std;

class ToroboDynamicsTestFixture : public ::testing::Test
{
protected:
    virtual void SetUp()
    {
    }
    virtual void TearDown()
    {
    }
};
