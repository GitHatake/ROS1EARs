#!/usr/bin/env python
## -*- coding: utf-8 -*-
import torobo_driver.set_payload_param_client

if __name__ == '__main__':
    torobo_driver.set_payload_param_client.main()