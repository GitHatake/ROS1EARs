# test for torobo_control

## How to build
```
$ catkin run_tests torobo_control
```

## How to launch

```
$ rostest --text torobo_control test_torobo_control_joint_trajectory_controller.test
$ rostest --text torobo_control test_torobo_control_gripper_controller.test
```
